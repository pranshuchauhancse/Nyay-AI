from fastapi import APIRouter
from app.schemas.legal_query import LegalQueryRequest, LegalQueryResponse

router = APIRouter()

@router.post("/legal-query", response_model=LegalQueryResponse)
def legal_query(payload: LegalQueryRequest):
    return {
        "summary": "Sample legal response",
        "acts": ["IPC"],
        "sections": ["420"],
        "steps": ["Consult a lawyer"],
        "disclaimer": "Not legal advice"
    }
