import api from "./api";

export const askLegalQuestion = async (question: string) => {
  const response = await api.post("/legal-query", { question });
  return response.data;
};
