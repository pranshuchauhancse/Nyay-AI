import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const LoginPage: React.FC = () => {
  const [email, setEmail] = useState("");
  const navigate = useNavigate();

  const login = () => {
    localStorage.setItem("token", "mock-token");
    navigate("/query");
  };

  return (
    <div>
      <h2>Login</h2>
      <input value={email} onChange={(e) => setEmail(e.target.value)} />
      <button onClick={login}>Login</button>
    </div>
  );
};

export default LoginPage;
