import React from "react";
import { useNavigate } from "react-router-dom";

const HomePage: React.FC = () => {
  const navigate = useNavigate();
  return (
    <div>
      <h1>NyayAI ⚖️</h1>
      <p>AI-powered legal information platform</p>
      <button onClick={() => navigate("/login")}>Get Started</button>
    </div>
  );
};

export default HomePage;
