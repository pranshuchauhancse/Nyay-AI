import React, { useState } from "react";
import { askLegalQuestion } from "../services/legalApi";

const LegalQueryPage: React.FC = () => {
  const [question, setQuestion] = useState("");
  const [response, setResponse] = useState<any>(null);

  const submit = async () => {
    const res = await askLegalQuestion(question);
    setResponse(res);
  };

  return (
    <div>
      <h2>Ask Legal Question</h2>
      <textarea value={question} onChange={(e) => setQuestion(e.target.value)} />
      <button onClick={submit}>Submit</button>

      {response && (
        <div>
          <p>{response.summary}</p>
          <p>{response.disclaimer}</p>
        </div>
      )}
    </div>
  );
};

export default LegalQueryPage;
