# NyayAI

AI-powered LegalTech platform for India.