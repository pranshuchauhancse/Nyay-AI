# Ethics Disclaimer

NyayAI provides legal information only and does not provide legal advice.
Always consult a qualified advocate.
