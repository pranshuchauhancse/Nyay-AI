# OpenAI API Usage

OpenAI GPT-4 is used for summarization and explanation.
AI is not treated as a legal authority.
